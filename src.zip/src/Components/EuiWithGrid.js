import React from 'react'
import { useState } from 'react';

import {
  EuiButtonEmpty,
  EuiContextMenuItem,
  EuiContextMenuPanel,
  EuiFlexGroup,
  EuiFlexItem,
  EuiPagination,
  EuiPopover,
} from '@elastic/eui';

function EuiWithGrid() {
    const [isPopoverOpen, setIsPopoverOpen] = useState(false);
        const [activePage, setActivePage] = useState(0);
      
        const PAGE_COUNT = 10;
      
        const onButtonClick = () => setIsPopoverOpen(isPopoverOpen => !isPopoverOpen);
        const closePopover = () => setIsPopoverOpen(false);
      
        const goToPage = pageNumber => setActivePage(pageNumber);
      
        const button = (
          <EuiButtonEmpty
            size="s"
            color="text"
            iconType="arrowDown"
            iconSide="right"
            onClick={onButtonClick}>
          </EuiButtonEmpty>
        );
      
        const items = [
          <EuiContextMenuItem
            key="10 rows"
            icon="empty"
            onClick={() => {
              closePopover();
             
            }}>
            10 rows
          </EuiContextMenuItem>,
          <EuiContextMenuItem
            key="20 rows"
            icon="empty"
            onClick={() => {
              closePopover();
             
            }}>
            20 rows
          </EuiContextMenuItem>,
          <EuiContextMenuItem
            key="50 rows"
            icon="check"
            onClick={() => {
              closePopover();
             
            }}>
            50 rows
          </EuiContextMenuItem>,
          <EuiContextMenuItem
            key="100 rows"
            icon="empty"
            >
            100 rows
          </EuiContextMenuItem>,
        ];
    return (
        <div>
            <EuiFlexGroup justifyContent="spaceBetween" alignItems="center">
            <EuiFlexItem grow={false}>
                <EuiPopover
                button={button}
                isOpen={isPopoverOpen}
                closePopover={closePopover}
                panelPaddingSize="none">
                <EuiContextMenuPanel items={items} />
                </EuiPopover>
            </EuiFlexItem>

            <EuiFlexItem grow={false}>
                <EuiPagination
                pageCount={PAGE_COUNT}
                activePage={activePage}
                onPageClick={goToPage}
                />
            </EuiFlexItem>
            </EuiFlexGroup>
        </div>
    )
}

export default EuiWithGrid
