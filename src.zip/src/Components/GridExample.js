import React, { Component } from 'react'
import { AgGridReact } from 'ag-grid-react'
import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-material.css';
import 'ag-grid-enterprise'
import EuiWithGrid from './EuiWithGrid'
import ComboBox from './ComboBox'
import { render } from 'react-dom';
import '@elastic/eui/dist/eui_theme_light.css'

import {
  EuiButton,
  EuiFlexGroup,
  EuiFlexItem,
  EuiIcon,
  EuiButtonEmpty,
  EuiContextMenuItem,
  EuiContextMenuPanel,
  EuiPagination,
  EuiButtonIcon,
  EuiPopover,
  EuiSwitch,
  EuiSpacer
} from '@elastic/eui';
let api=''

 class GridExample extends Component {

constructor(props) {
  super(props)

this.state = {
  isPopoverOpen: false,
   isFirstName: true,

            isLastName: true,
            isBranch: true,
            isContact: true,
            isEmail: true,
            isAction: true,
            isTags: true,
columnDefs: [
   {
    headerName: "FirstName", field: "firstname", 
    getQuickFilterText: function(params){
      return params.value.firstname
    }
  }, {
    headerName: "LastName", field: "lastname"
  }, 
   {
    headerName: "Branch", field: "branch"
  }, {
    headerName: "Contact", field: "contact"
  }, 
  {
    headerName: "Tags", field: "tags", cellRendererFramework: function(params) {
       return(
      <ComboBox />
      )
    }

  }, 
  {
    headerName: "Email", field: "email"
  },
  {

                headerName: "Actions", field: "action",
                cellRendererFramework: function (params) {
                    const deleteRow = () => {
              
                        const selectedData = api.getSelectedRows();
                        api.updateRowData({ remove: selectedData });

                }
                return (
                    <>
                        <EuiIcon type="trash" onClick={deleteRow} />
                    </>
                )
            }          
          },
 
],
  defaultColDef: { 
    editable: true,
    enableRowGroup: true,
    enablePivot: true,
    enableValue: true,
    sortable: true,
    resizable: true,
    filter: true,
    flex: 1,
    minWidth: 100,
    rowSelection: 'multiple',
    rowGroupPanelShow: 'always',
    pivotPanelShow: 'always', 
    },
    
    rowData: [{
      firstname: "Dhairya",
      lastname: "Shah",
      branch: "IT",
      contact: 9429020011,
      email: "dhairya.shah@rapidops.com"
    },
    
    {
      firstname: "Meet",
      lastname: "Shah",
      branch: "CS",
      contact: 7982124770,
      email: "meet.shah@rapidops.com"
    },
    {
      firstname: "Darshan",
      lastname: "Vesatiya",
      branch: "IT",
      contact: 9870912667,
      email: "darshan.vesatiya@gmail.com"
    },
    {
      
      firstname: "Hardik",
      lastname: "Motwani",
      branch: "CS",
      contact: 9870912668,
      email: "hardik.motwani@gmail.com"
    },
    {
    
      firstname: "Brijesh",
      lastname: "Shah",
      branch: "M.Sc.(IT)",
      contact: 9870912669,
      email: "Brijesh.shah@rapidops.com"
    },
    {
     
      firstname: "Gaurav",
      lastname: 'Bhatt',
      branch: "M.Sc.(IT)",
      contact: 9870912660,
      email: "Gaurav@gmail.com"
    },
    {
      
      firstname: "Jatin",
      lastname: "Jain",
      branch: "IT",
      contact: 9870912610,
      email: "jatin@gmail.com"
    },
    {
      firstname: "Maitri",
      lastname: "Patel",
      branch: "BCA",
      contact: 9870912611,
      email: "maitri@gmail.com"
    },
    {
      firstname: "Prachi",
      lastname: "Patel",
      branch: "MCA",
      contact: 9870912611,
      email: "Prachi@gmail.com"
    },
    ],
}
this.deleteRow=this.deleteRow.bind(this)
}

onGridReady = params => {

  api = params.api;
   this.columnApi = params.columnApi;
}
onButtonClick = e => {
        const selectedNodes = api.getSelectedNodes()
        const selectedData = selectedNodes.map(node => node.data)
        const selectedDataStringPresentation = selectedData.map(a => a.firstname + ' ' + a.lastname + ' From ' + a.branch).join('\n ')

    alert(`Selected nodes: ${'\n'}${selectedDataStringPresentation}`)
}
closePopover() {
    this.setState({
        isPopoverOpen: false,
    });
}
manage = () => {
    this.setState({
        isPopoverOpen: !this.state.isPopoverOpen,
    });
}
display(value, col, set) {
this.setState({
    [set]: value,
})
this.columnApi.setColumnVisible(col, value)
}

  deleteRow=()=>
 { 
   const selectedData = this.api.getSelectedRows();
     this.api.updateRowData({ remove: selectedData });
    

} 

onFilterTextBoxChanged = () => {

  api.setQuickFilter(document.getElementById('filter-text-box').value)
}

render() {
  const {rowData,columnDefs,defaultColDef,isFirstName,isLastName,isBranch,isContact,isTags,isEmail,isAction}=this.state

  const button = (
            <EuiIcon type="gear" size="xl" className="popover"  onClick={this.manage.bind(this)} />
        );
  return (
    <div
      className="ag-theme-material"
      style={{ width: '100%', height: '600px' }}>
        
                <div>
                Search : <input  type="text" id="filter-text-box" className="ag-theme-material" onInput={this.onFilterTextBoxChanged}/>
                     <EuiPopover
                        ownFocus
                        button={button}
                        isOpen={this.state.isPopoverOpen}
                        closePopover={this.closePopover.bind(this)}
                    >
                        <div>
                            <EuiSwitch
                                label="FirstName"
                                checked={isFirstName}
                                onChange={e => this.display(e.target.checked, 'FirstName', "isFirstName")}
                            />
                            <EuiSpacer size="s" />
                            <EuiSwitch
                                label="LastName"
                                checked={isLastName}
                                onChange={e => this.display(e.target.checked, 'LastName', "isLastName")}
                            />
                            <EuiSpacer size="s" />
                            <EuiSwitch
                                label="Branch"
                                checked={isBranch}
                                onChange={e => this.display(e.target.checked, 'Branch', "isBranch")}
                            />

                            <EuiSpacer size="s" />
                            <EuiSwitch
                                label="Contact"
                                checked={isContact}
                                onChange={e => this.display(e.target.checked, 'Contact', "isContact")}
                            />
                             <EuiSpacer size="s" />
                            <EuiSwitch
                                label="Tags"
                                checked={isTags}
                                onChange={e => this.display(e.target.checked, 'Tags', "isTags")}
                            />
                            <EuiSpacer size="s" />
                            <EuiSwitch
                                label="Email"
                                checked={isEmail}
                                onChange={e => this.display(e.target.checked, 'Email', "isEmail")}
                            />
                            <EuiSpacer size="s" />
                            <EuiSwitch
                                label="Action"
                                checked={isAction}
                                onChange={e => this.display(e.target.checked, 'Actions', "isAction")}
                            />

                        </div >
                    </EuiPopover> 

            </div>
  
       <AgGridReact
       modules={this.state.modules}
       columnDefs={this.state.columnDefs}
       autoGroupColumnDef={this.state.autoGroupColumnDef}
       defaultColDef={this.state.defaultColDef}
       suppressRowClickSelection={true}
       groupSelectsChildren={true}
       debug={true}
       rowSelection={this.state.rowSelection}
       rowGroupPanelShow={this.state.rowGroupPanelShow}
       pivotPanelShow={this.state.pivotPanelShow}
       enableRangeSelection={true}
      columnDefs={columnDefs}
      rowData={rowData}
      defaultColDef={defaultColDef}
      
      onGridReady={this.onGridReady}
      suppressClickEdit={true}
      pagination={true}
      paginationPageSize={10}
    
>                           
  </AgGridReact>
  <EuiWithGrid />



</div>
  )
}
}

export default GridExample;