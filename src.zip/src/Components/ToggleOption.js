import React, { Fragment, useState } from 'react';

import {
  EuiColorPicker,
  EuiColorStops,
  EuiButton,
  EuiPopover,
  EuiFormRow,
  EuiModal,
  EuiModalBody,
  EuiModalHeader,
  EuiModalHeaderTitle,
  EuiOverlayMask,
  EuiSpacer,
  EuiIcon,
} from '@elastic/eui';

import {
  useColorPickerState,
  useColorStopsState,
} from '@elastic/eui/lib/services';

export default () => {
  const [color, setColor] = useColorPickerState();
  const [colorStops, setColorStops] = useColorStopsState();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isPopoverOpen, setIsPopoverOpen] = useState(false);

  const closeModal = () => {
    setIsModalVisible(false);
  };

  const showModal = () => {
    setIsModalVisible(true);
  };

  const togglePopover = () => {
    setIsPopoverOpen(!isPopoverOpen);
  };

  const closePopover = () => {
    setIsPopoverOpen(false);
  };

//   const colorPicker = <EuiColorPicker color={color} onChange={setColor} />;
const fnm = (<p>Firstname</p>)
    

  const stops = (
    <EuiColorStops
      label="Color stops"
      onChange={setColorStops}
      colorStops={colorStops}
      min={0}
      max={100}
    />
  );

  const button = (
      <div>
        <EuiIcon type="gear" size="xl" iconSide="right" onClick={togglePopover}/>
        <h1>View Settings</h1>
      </div>
   
  );

  let modal;

  if (isModalVisible) {
    modal = (
      <EuiOverlayMask>
        <EuiModal onClose={closeModal} style={{ width: '800px' }}>
          <EuiModalHeader>
            <EuiModalHeaderTitle>Color picker in a modal</EuiModalHeaderTitle>
          </EuiModalHeader>

          <EuiModalBody>
            {/* <EuiFormRow label="Color picker">{colorPicker}</EuiFormRow> */}
            <EuiSpacer />
            <EuiFormRow label="Color stops">{stops}</EuiFormRow>
          </EuiModalBody>
        </EuiModal>
      </EuiOverlayMask>
    );
  }

  return (
    <Fragment>   
        <EuiPopover
          id="popover"
          ownFocus={true}
          button={button}
          isOpen={isPopoverOpen}
          closePopover={closePopover}>
          <div style={{ width: '300px' }}>
            {/* <EuiFormRow label="Color picker">{colorPicker}</EuiFormRow> */}
            <EuiIcon type="eye">{fnm}</EuiIcon>
            <EuiSpacer />
            <EuiFormRow label="Color stops">{stops}</EuiFormRow>
          </div>
        </EuiPopover>
   

     
    </Fragment>
  );
};

